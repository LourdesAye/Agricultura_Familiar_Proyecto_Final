package com.example.agroagil.Login.ui

/*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.components.ViewModelComponent

@Module
@InstallIn(ViewModelComponent::class)
object LoginGoogleViewModelModule {
    @Provides
    fun provideLoginGoogleViewModel(): LoginGoogleViewModel {
        return LoginGoogleViewModel()
    }
}
*/

//considerar el otro archivo borrado