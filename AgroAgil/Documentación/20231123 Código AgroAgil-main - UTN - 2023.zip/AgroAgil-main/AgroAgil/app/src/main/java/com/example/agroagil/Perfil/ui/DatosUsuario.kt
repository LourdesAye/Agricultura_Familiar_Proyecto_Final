package com.example.agroagil.Perfil.ui

data class DatosUsuario(
    val apellido: String = "",
    val correoElectronico: String = "",
    val nombre: String = "",
    val rol: String = ""
)
