package com.example.agroagil.Perfil.ui

data class PerfilUsuario(
    var nombreUsuario : String,
    var apellidoUsuario : String,
    var correoElectronico : String,
    var rolUsuario: String,
    var contraseña : String
)
