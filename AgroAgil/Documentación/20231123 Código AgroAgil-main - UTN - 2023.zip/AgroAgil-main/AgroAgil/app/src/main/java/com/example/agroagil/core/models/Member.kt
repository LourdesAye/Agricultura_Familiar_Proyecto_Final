package com.example.agroagil.core.models

data class Member (
    val name: String="",
    val role: String="",
    val correo: String="",
    val image: String=""
)